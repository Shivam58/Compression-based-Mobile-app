package com.jmatio.types;

public interface GenericArrayCreator<T>
{
    T[] createArray(int m, int n);

}
